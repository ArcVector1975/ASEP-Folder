// Background Script - simple service worker
chrome.runtime.onInstalled.addListener(() => {
    console.log("Email Scanner extension installed.");
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    // placeholder for background message handling in future
});
