Email Scanner Chrome Extension
------------------------------
Files included:
- manifest.json        (required by Chrome)
- content.js           (extracts email body + links)
- background.js        (service worker)
- popup.html           (UI)
- popup.js             (popup logic)
- icon.png             (simple placeholder icon)

How to load:
1. Unzip this folder.
2. Open Chrome and go to chrome://extensions/
3. Enable Developer mode (top-right).
4. Click 'Load unpacked' and select the unzipped folder (the folder that contains manifest.json).
5. Open mail.google.com or outlook.office.com, open an email, click the extension icon and then 'Scan Current Email'.

If Chrome shows 'manifest not found' error, make sure you selected the folder that directly contains manifest.json (not a parent folder).
