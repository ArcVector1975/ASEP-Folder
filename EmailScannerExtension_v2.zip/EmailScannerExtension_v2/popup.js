// popup.js - improved & resilient version

const scanBtn = document.getElementById("scanBtn");
const copyBtn = document.getElementById("copyBtn");
const output = document.getElementById("output");

function showText(text) {
  output.textContent = text;
}

function showError(msg) {
  output.textContent = "Error: " + msg;
}

async function requestExtraction() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) {
      showError("No active tab found.");
      return null;
    }

    return new Promise((resolve) => {
      chrome.tabs.sendMessage(tab.id, { action: "scanEmail" }, (response) => {
        if (chrome.runtime.lastError) {
          resolve({ error: chrome.runtime.lastError.message });
          return;
        }
        if (!response || !response.text) {
          resolve({ error: "No text found on this page. Make sure you're on an open email." });
          return;
        }
        resolve({ ok: true, data: response });
      });

      setTimeout(() => resolve({ error: "Content script didn't respond (timeout)." }), 4000);
    });
  } catch (e) {
    showError(e.message || "Unknown error while querying tab.");
    return null;
  }
}

scanBtn.addEventListener("click", async () => {
  showText("Scanning...");
  const result = await requestExtraction();

  if (!result) return;

  if (result.error) {
    showError(result.error);
    return;
  }

  const { text, links } = result.data;
  let out = "Extracted text:\n\n" + text.trim();
  if (links && links.length) {
    out += "\n\nLinks found:\n" + links.join("\n");
  }
  showText(out);

  /*
  try {
    const res = await fetch("http://localhost:5000/classify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email_text: text })
    });
    if (res.ok) {
      const json = await res.json();
      alert(`Result: ${json.label}\nReason: ${json.reason}`);
    }
  } catch (err) {
    console.warn("Could not contact backend:", err.message);
  }
  */
});

copyBtn.addEventListener("click", async () => {
  const text = output.textContent || "";
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
    copyBtn.textContent = "Copied!";
    setTimeout(() => (copyBtn.textContent = "Copy Text"), 1000);
  } catch (e) {
    const ta = document.createElement("textarea");
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand("copy"); copyBtn.textContent = "Copied!"; }
    catch(e2) { alert("Copy failed."); }
    ta.remove();
    setTimeout(() => (copyBtn.textContent = "Copy Text"), 1000);
  }
});