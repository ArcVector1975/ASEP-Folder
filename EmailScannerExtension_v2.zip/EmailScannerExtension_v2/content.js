// Content Script - Extract Email Body
console.log("Content Script Loaded.");

function getGmailBody() {
    // try a few selectors commonly used by Gmail
    const selectors = [".a3s.aiL", ".ii.gt", "div[role='listitem'] .adn, .adn .ii"];
    for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el && el.innerText && el.innerText.trim().length > 10) {
            return el.innerText.trim();
        }
    }
    // fallback: try the largest text-containing element
    let largest = "";
    document.querySelectorAll("div").forEach(d => {
        const t = (d.innerText || "").trim();
        if (t.length > largest.length) largest = t;
    });
    return largest;
}

function getOutlookBody() {
    const selectors = ["[role='document']", ".ReadingPaneContainer", ".rpBody"];
    for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el && el.innerText && el.innerText.trim().length > 10) {
            return el.innerText.trim();
        }
    }
    return "";
}

function extractBody() {
    try {
        if (location.host.includes("mail.google.com")) {
            return getGmailBody();
        }
        if (location.host.includes("outlook.office.com")) {
            return getOutlookBody();
        }
        return "";
    } catch (e) {
        console.error("Extraction error:", e);
        return "";
    }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.action === "scanEmail") {
        const emailText = extractBody();
        // also extract links
        const links = Array.from(document.querySelectorAll("a"))
            .map(a => a.href)
            .filter(h => h && h.startsWith("http"));
        sendResponse({ text: emailText, links });
    }
    return true; // indicate async response (safe)
});
